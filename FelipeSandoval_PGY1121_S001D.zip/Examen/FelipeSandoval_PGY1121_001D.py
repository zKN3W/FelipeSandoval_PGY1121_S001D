import os
depto=[[True for a in range(4)] for a in range(10)]
letras=["A","B","C","D"]
compradores=[]

os.system("cls")
def mostrar_menu():
    print("1- Comprar departamento                ")
    print("2- Mostrar departamentos disponibles   ")
    print("3- Ver listado de compradores          ")
    print("4- Mostrar ganancias totales           ")
    print("5- Salir                               ")
    op=input("Ingrese opcion (1 al 5): ")
    return op

def val_opc(opc):
    try:
        opcion = int(opc)
        if opcion<1 or opcion>5:
            raise ValueError
        return True
    except ValueError:
        return False

def val_piso(piso):
    try:
        piso = int(piso)
        if piso<1 or piso>10:
            raise ValueError
        return True
    except ValueError:
        return False

def val_tipo(tipo):
    if len(tipo) == 1 and tipo.isalpha():
        tipo = tipo.upper()
        if tipo in letras:
            return True
    return False

def val_rut(rut):
    if len(rut)==8 and rut.isdigit():
        return True
    return False

def comprar_departamento():
    mostrar_departamentos()
    piso=input("Ingrese el piso del departamento a comprar (1 a 10): ")
    tipo=input("Ingrese el tipo del departamento a comprar (A,B,C o D): ")
    if val_piso(piso) and val_tipo(tipo):
        piso=int(piso)-1
        tipo=letras.index(tipo.upper())
        if depto[piso][tipo]:
            rut=input("Ingrese el RUT del comprador : ")
            if val_rut(rut):
                depto[piso][tipo] = False
                compradores.append((rut, piso + 1, tipo + 1))
                print(f"La compra del departamento {piso + 1} se ha realizado de manera exitosa.")
            else:
                print("El RUT que ingresó no es válido. Intentelo nuevamente.")
        else:
            print(f"El departamento {letras[tipo]}{piso+1} no está disponible. Intente con otro.")
    else:
        print("ERROR!!! intentalo nuevamente.")
        
def mostrar_departamentos():
    print("Departamentos disponibles:")
    print("Piso\tA\tB\tC\tD")
    for i in range(10):  
        print(f"{i+1}", end="\t")
        for j in range(4):
            if depto[i][j]:
                print(letras[j], end="\t")
            else:
                print("X", end="\t")
        print()

continuar=True
def salir():
    print("Saliendo del sistema... Programa de Felipe Sandoval 11-07-2023")
while continuar:
    opcion=mostrar_menu()
    if val_opc(opcion):
        opcion = int(opcion)
        if opcion==1:
            os.system("cls") 
            comprar_departamento()
        elif opcion==2:
            os.system("cls")
            mostrar_departamentos()
        elif opcion==5:
            os.system("cls")
            salir()
            continuar = False
    else:
        print("La opción que ingresó no es valida. Intentelo nuevamente.")
